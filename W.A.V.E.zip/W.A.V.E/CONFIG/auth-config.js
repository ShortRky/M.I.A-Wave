const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const express = require('express');

const app = express();

app.use(cookieParser());

const secretKey = 'your_secret_key';

// Function to generate JWT token
function generateToken(user) {
    return jwt.sign(user, secretKey, { expiresIn: '1h' });
}

// Middleware to authenticate user
function authenticateToken(req, res, next) {
    const token = req.cookies.token || req.headers['authorization'];
    if (!token) return res.sendStatus(401);

    jwt.verify(token, secretKey, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
}

// Login route
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    // Validate user credentials (this is just a placeholder, implement your own logic)
    if (username === 'user' && password === 'password') {
        const user = { username };
        const token = generateToken(user);
        res.cookie('token', token, { httpOnly: true });
        res.json({ message: 'Logged in successfully' });
    } else {
        res.status(401).json({ message: 'Invalid credentials' });
    }
});

// Logout route
app.post('/logout', (req, res) => {
    res.clearCookie('token');
    res.json({ message: 'Logged out successfully' });
});

module.exports = { authenticateToken };