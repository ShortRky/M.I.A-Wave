const session = await stripe.checkout.sessions.create({
    payment_method_types: ["card"],
    line_items: [
        {
            price: "your_product_price_id",
            quantity: 1,
        },
    ],
    mode: "payment",
    success_url: "https://WAVE.github.io/success.html",  // Redirects after successful payment
    cancel_url: "https://WAVE.github.io/cancel.html",   // Redirects if user cancels
});
