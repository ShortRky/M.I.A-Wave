const stripe = require('stripe')('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');

const createCheckoutSession = async (req, res) => {
    const session = await stripe.checkout.sessions.create({
        payment_method_types: ['card'],
        line_items: [{
            price_data: {
                currency: 'cad',
                product_data: {
                    name: 'W.A.V.E Premium Membership',
                },
                unit_amount: 2000, // $20.00
            },
            quantity: 1,
        }],
        mode: 'payment',
        success_url: 'https://your-website.com/success',
        cancel_url: 'https://your-website.com/cancel',
    });

    res.json({ id: session.id });
};

module.exports = { createCheckoutSession };