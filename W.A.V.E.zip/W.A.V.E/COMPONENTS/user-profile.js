import React, { useState } from 'react';

const UserProfile = () => {
    const [user, setUser] = useState({
        name: 'John Doe',
        email: 'john.doe@example.com',
        password: 'password123'
    });

    const [isEditing, setIsEditing] = useState(false);
    const [formData, setFormData] = useState(user);

    const handleEdit = () => {
        setIsEditing(true);
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value
        });
    };

    const handleSave = () => {
        setUser(formData);
        setIsEditing(false);
    };

    const handleDelete = () => {
        // Handle account deletion logic here
        console.log('Account deleted');
    };

    return (
        <div>
            <h1>User Profile</h1>
            {isEditing ? (
                <div>
                    <label>
                        Name:
                        <input type="text" name="name" value={formData.name} onChange={handleChange} />
                    </label>
                    <br />
                    <label>
                        Email:
                        <input type="email" name="email" value={formData.email} onChange={handleChange} />
                    </label>
                    <br />
                    <label>
                        Password:
                        <input type="password" name="password" value={formData.password} onChange={handleChange} />
                    </label>
                    <br />
                    <button onClick={handleSave}>Save</button>
                </div>
            ) : (
                <div>
                    <p>Name: {user.name}</p>
                    <p>Email: {user.email}</p>
                    <p>Password: {user.password}</p>
                    <button onClick={handleEdit}>Edit</button>
                </div>
            )}
            <button onClick={handleDelete}>Delete Account</button>
        </div>
    );
};

export default UserProfile;