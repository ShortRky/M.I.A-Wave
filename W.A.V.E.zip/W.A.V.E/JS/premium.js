document.getElementById("premium-access-btn").addEventListener("click", function () {
    // Placeholder for redirecting to Stripe checkout or other premium features
    alert("Redirecting to premium checkout...");
    window.location.href = "payment.html";  // Redirect to payment page
});