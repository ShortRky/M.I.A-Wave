document.getElementById("payment-form").addEventListener("submit", function (e) {
    e.preventDefault();
    // Placeholder for payment processing logic
    alert("Processing payment...");
});
